Functions in this folder include multiple generalized calculation functions.


Such as Filer, FFT etc....
