# -*- coding: utf-8 -*-
"""
Created on Thu May 13 16:57:23 2021

@author: ZR
These fuctions are used to produce data of all_Index matrix. Use this to decrease repeat.
"""

