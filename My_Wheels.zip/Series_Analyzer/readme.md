These functions are used for Cell Train analyze.
It's very useful in spontaneous data analyze.


All input cell data shall be in format of pandas DataFrame.
RAW F value data input, normalize and dF/F calculated as needed.

Each row is a cell train, row name as cell name, column name as seconds.


